import { Album } from './album';

describe('Album', () => {
  it('should create an instance', () => {
    expect(new Album()).toBeTruthy();
  });
});
